#include <bits/stdc++.h>
using namespace std;

bool formatacao(string teste);

int ataques(string arquivos);