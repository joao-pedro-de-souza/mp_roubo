#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main() - only do this in one cpp file
#include "catch.hpp"
#include "rainhas.hpp"


TEST_CASE("Se a função lê o arquivo") {
   REQUIRE(ataques("teste1.txt") == 0);
}

TEST_CASE("Se o arquivo tem 8 linhas") {
   REQUIRE(ataques("teste2.txt") == 0);
   REQUIRE(ataques("teste3.txt") == -1);
}